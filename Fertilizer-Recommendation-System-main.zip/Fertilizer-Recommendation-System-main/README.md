# Fertilizer-Recommendation-System
Fertilizer Recommendation webpage and android app.
This is a Machine Learning Project using python and jupyter notebook.
Disclaimer :- This project is for training and learning purpose only. 
